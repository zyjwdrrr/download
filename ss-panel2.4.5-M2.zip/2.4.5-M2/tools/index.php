<?php
echo time();